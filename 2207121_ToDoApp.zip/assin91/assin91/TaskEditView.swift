//
//  TaskEditView.swift
//  assign91
//
//  Created by macos on 4/11/26.
//

import SwiftUI

/// Used for both creating (task == nil) and editing a task.
struct TaskEditView: View {
    let task: TodoTask?
    let onSave: (_ title: String, _ description: String) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var title: String
    @State private var description: String
    @FocusState private var titleFocused: Bool

    init(task: TodoTask?, onSave: @escaping (String, String) -> Void) {
        self.task = task
        self.onSave = onSave
        _title = State(initialValue: task?.title ?? "")
        _description = State(initialValue: task?.description ?? "")
    }

    private var trimmedTitle: String {
        title.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func save() {
        onSave(trimmedTitle,
               description.trimmingCharacters(in: .whitespacesAndNewlines))
        dismiss()
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AppBackground()

                ScrollView {
                    VStack(spacing: 18) {
                        VStack(alignment: .leading, spacing: 10) {
                            Label("Title", systemImage: "textformat")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(AppTheme.accent)
                            TextField("e.g. Finish lab report", text: $title)
                                .font(.title3.weight(.medium))
                                .focused($titleFocused)
                                .submitLabel(.done)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(18)
                        .card()

                        VStack(alignment: .leading, spacing: 10) {
                            Label("Description", systemImage: "text.alignleft")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(AppTheme.accent)
                            ZStack(alignment: .topLeading) {
                                TextEditor(text: $description)
                                    .scrollContentBackground(.hidden)
                                    .frame(minHeight: 160)
                                if description.isEmpty {
                                    Text("Add some details (optional)")
                                        .foregroundStyle(.tertiary)
                                        .padding(.top, 8)
                                        .padding(.leading, 5)
                                        .allowsHitTesting(false)
                                }
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(18)
                        .card()

                        Button {
                            save()
                        } label: {
                            Text(task == nil ? "Add Task" : "Save Changes")
                        }
                        .buttonStyle(PrimaryButtonStyle())
                        .disabled(trimmedTitle.isEmpty)
                        .padding(.top, 6)
                    }
                    .padding(20)
                }
                .scrollDismissesKeyboard(.interactively)
            }
            .navigationTitle(task == nil ? "New Task" : "Edit Task")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { save() }
                        .fontWeight(.semibold)
                        .disabled(trimmedTitle.isEmpty)
                }
            }
            .onAppear { if task == nil { titleFocused = true } }
        }
        .tint(AppTheme.accent)
    }
}
