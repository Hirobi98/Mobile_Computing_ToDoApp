import SwiftUI

// MARK: - Shared look & feel (UI only)

enum AppTheme {
    static let accent = Color(red: 0.38, green: 0.33, blue: 0.93)
    static let accent2 = Color(red: 0.55, green: 0.36, blue: 0.96)
    static let done = Color(red: 0.20, green: 0.72, blue: 0.52)

    static var accentGradient: LinearGradient {
        LinearGradient(colors: [accent, accent2], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
}

/// Soft gradient used behind every screen.
struct AppBackground: View {
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        ZStack {
            (scheme == .dark ? Color(red: 0.07, green: 0.07, blue: 0.11)
                             : Color(red: 0.96, green: 0.96, blue: 0.99))
            Circle()
                .fill(AppTheme.accent.opacity(scheme == .dark ? 0.25 : 0.18))
                .frame(width: 320, height: 320)
                .blur(radius: 70)
                .offset(x: -140, y: -300)
            Circle()
                .fill(AppTheme.accent2.opacity(scheme == .dark ? 0.20 : 0.14))
                .frame(width: 280, height: 280)
                .blur(radius: 70)
                .offset(x: 160, y: 320)
        }
        .ignoresSafeArea()
    }
}

/// Rounded white/dark card container.
struct CardStyle: ViewModifier {
    @Environment(\.colorScheme) private var scheme

    func body(content: Content) -> some View {
        content
            .background(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(scheme == .dark ? Color(red: 0.12, green: 0.12, blue: 0.17) : Color.white)
            )
            .shadow(color: Color.black.opacity(scheme == .dark ? 0.0 : 0.06), radius: 12, x: 0, y: 4)
    }
}

extension View {
    func card() -> some View { modifier(CardStyle()) }
}

/// Full-width gradient button look.
struct PrimaryButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var isEnabled

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline)
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(AppTheme.accentGradient)
            )
            .opacity(isEnabled ? 1 : 0.45)
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
            .animation(.easeOut(duration: 0.15), value: configuration.isPressed)
    }
}

// MARK: - Login / Sign up

struct LoginView: View {
    @EnvironmentObject var auth: AuthViewModel
    @State private var email = ""
    @State private var password = ""
    @State private var isSignUp = false

    private enum Field { case email, password }
    @FocusState private var focused: Field?

    private var canSubmit: Bool {
        !email.trimmingCharacters(in: .whitespaces).isEmpty && password.count >= 6
    }

    var body: some View {
        ZStack {
            AppBackground()

            ScrollView {
                VStack(spacing: 28) {
                    header
                        .padding(.top, 60)

                    VStack(spacing: 14) {
                        inputRow(icon: "envelope.fill") {
                            TextField("Email", text: $email)
                                .textContentType(.emailAddress)
                                .keyboardType(.emailAddress)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .focused($focused, equals: .email)
                                .submitLabel(.next)
                                .onSubmit { focused = .password }
                        }

                        inputRow(icon: "lock.fill") {
                            SecureField("Password (min 6 characters)", text: $password)
                                .textContentType(isSignUp ? .newPassword : .password)
                                .focused($focused, equals: .password)
                                .submitLabel(.go)
                        }

                        if password.count > 0 && password.count < 6 {
                            Label("Password must be at least 6 characters", systemImage: "info.circle")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.horizontal, 4)
                        }

                        if let error = auth.errorMessage {
                            HStack(alignment: .top, spacing: 8) {
                                Image(systemName: "exclamationmark.triangle.fill")
                                Text(error).font(.footnote)
                                Spacer(minLength: 0)
                            }
                            .foregroundStyle(.red)
                            .padding(12)
                            .background(
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .fill(Color.red.opacity(0.10))
                            )
                        }
                    }
                    .padding(20)
                    .card()

                    VStack(spacing: 16) {
                        Button {
                            focused = nil
                            Task {
                                let e = email.trimmingCharacters(in: .whitespaces)
                                if isSignUp { await auth.signUp(email: e, password: password) }
                                else { await auth.signIn(email: e, password: password) }
                            }
                        } label: {
                            HStack(spacing: 10) {
                                if auth.isLoading {
                                    ProgressView().tint(.white)
                                } else {
                                    Text(isSignUp ? "Create Account" : "Log In")
                                    Image(systemName: "arrow.right")
                                }
                            }
                        }
                        .buttonStyle(PrimaryButtonStyle())
                        .disabled(!canSubmit || auth.isLoading)

                        HStack(spacing: 4) {
                            Text(isSignUp ? "Already have an account?" : "New here?")
                                .foregroundStyle(.secondary)
                            Button(isSignUp ? "Log In" : "Sign Up") {
                                auth.errorMessage = nil
                                withAnimation(.easeInOut(duration: 0.2)) { isSignUp.toggle() }
                            }
                            .fontWeight(.semibold)
                            .tint(AppTheme.accent)
                        }
                        .font(.subheadline)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 40)
            }
            .scrollDismissesKeyboard(.interactively)
        }
    }

    private var header: some View {
        VStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 26, style: .continuous)
                    .fill(AppTheme.accentGradient)
                    .frame(width: 84, height: 84)
                    .shadow(color: AppTheme.accent.opacity(0.35), radius: 16, x: 0, y: 8)
                Image(systemName: "checkmark")
                    .font(.system(size: 38, weight: .bold))
                    .foregroundStyle(.white)
            }
            VStack(spacing: 6) {
                Text(isSignUp ? "Create your account" : "Welcome back")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                Text(isSignUp ? "Start organising your tasks today."
                              : "Log in to see your tasks.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private func inputRow<Content: View>(icon: String, @ViewBuilder content: () -> Content) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(AppTheme.accent)
                .frame(width: 22)
            content()
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 14)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(Color.primary.opacity(0.05))
        )
    }
}
