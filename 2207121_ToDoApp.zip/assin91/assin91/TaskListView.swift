//
//  TaskListView.swift
//  assign91
//
//  Created by macos on 4/11/26.
//

import SwiftUI

struct TaskListView: View {
    @EnvironmentObject var auth: AuthViewModel
    @StateObject private var vm = TaskViewModel()

    @State private var showingAdd = false
    @State private var editingTask: TodoTask?
    @State private var filter: Filter = .all

    enum Filter: String, CaseIterable, Identifiable {
        case all = "All", active = "Active", done = "Done"
        var id: String { rawValue }
    }

    private var completedCount: Int { vm.tasks.filter { $0.isCompleted }.count }

    private var progress: Double {
        vm.tasks.isEmpty ? 0 : Double(completedCount) / Double(vm.tasks.count)
    }

    private var visibleTasks: [TodoTask] {
        switch filter {
        case .all: return vm.tasks
        case .active: return vm.tasks.filter { !$0.isCompleted }
        case .done: return vm.tasks.filter { $0.isCompleted }
        }
    }

    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottomTrailing) {
                AppBackground()

                Group {
                    if vm.tasks.isEmpty {
                        emptyState(icon: "checklist",
                                   title: "No tasks yet",
                                   message: "Tap + to add your first task.")
                    } else {
                        List {
                            summaryCard
                                .listRowInsets(EdgeInsets(top: 8, leading: 20, bottom: 4, trailing: 20))
                                .listRowSeparator(.hidden)
                                .listRowBackground(Color.clear)

                            Picker("Filter", selection: $filter) {
                                ForEach(Filter.allCases) { Text($0.rawValue).tag($0) }
                            }
                            .pickerStyle(.segmented)
                            .listRowInsets(EdgeInsets(top: 8, leading: 20, bottom: 8, trailing: 20))
                            .listRowSeparator(.hidden)
                            .listRowBackground(Color.clear)

                            if visibleTasks.isEmpty {
                                emptyState(icon: filter == .done ? "tray" : "party.popper",
                                           title: filter == .done ? "Nothing completed yet" : "All caught up",
                                           message: filter == .done ? "Finish a task and it will show up here."
                                                                    : "No active tasks left.")
                                    .padding(.top, 40)
                                    .listRowSeparator(.hidden)
                                    .listRowBackground(Color.clear)
                            }

                            ForEach(visibleTasks) { task in
                                taskRow(task)
                                    .listRowInsets(EdgeInsets(top: 6, leading: 20, bottom: 6, trailing: 20))
                                    .listRowSeparator(.hidden)
                                    .listRowBackground(Color.clear)
                                    .swipeActions {
                                        Button(role: .destructive) { vm.delete(task) } label: {
                                            Label("Delete", systemImage: "trash")
                                        }
                                    }
                            }

                            Color.clear.frame(height: 70)
                                .listRowSeparator(.hidden)
                                .listRowBackground(Color.clear)
                        }
                        .listStyle(.plain)
                        .scrollContentBackground(.hidden)
                    }
                }

                addButton
                    .padding(.trailing, 24)
                    .padding(.bottom, 24)
            }
            .navigationTitle("My Tasks")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        vm.stop(); auth.signOut()
                    } label: {
                        Label("Log Out", systemImage: "rectangle.portrait.and.arrow.right")
                            .labelStyle(.titleAndIcon)
                            .font(.subheadline)
                    }
                }
            }
            .sheet(isPresented: $showingAdd) {
                TaskEditView(task: nil) { title, desc in vm.add(title: title, description: desc) }
            }
            .sheet(item: $editingTask) { task in
                TaskEditView(task: task) { title, desc in
                    var t = task
                    t.title = title
                    t.description = desc
                    vm.update(t)
                }
            }
            .alert("Error", isPresented: Binding(
                get: { vm.errorMessage != nil },
                set: { if !$0 { vm.errorMessage = nil } })
            ) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(vm.errorMessage ?? "")
            }
        }
        .tint(AppTheme.accent)
        .onAppear { if let uid = auth.user?.uid { vm.start(uid: uid) } }
        .onDisappear { vm.stop() }
    }

    // MARK: - Pieces

    private var summaryCard: some View {
        HStack(spacing: 18) {
            ZStack {
                Circle().stroke(Color.white.opacity(0.25), lineWidth: 8)
                Circle()
                    .trim(from: 0, to: progress)
                    .stroke(Color.white, style: StrokeStyle(lineWidth: 8, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                    .animation(.easeInOut(duration: 0.4), value: progress)
                Text("\(Int(progress * 100))%")
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(.white)
            }
            .frame(width: 64, height: 64)

            VStack(alignment: .leading, spacing: 4) {
                Text(progress == 1 ? "All done!" : "Your progress")
                    .font(.headline)
                Text("\(completedCount) of \(vm.tasks.count) tasks completed")
                    .font(.subheadline)
                    .opacity(0.85)
            }
            .foregroundStyle(.white)

            Spacer(minLength: 0)
        }
        .padding(18)
        .background(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(AppTheme.accentGradient)
        )
        .shadow(color: AppTheme.accent.opacity(0.30), radius: 14, x: 0, y: 8)
    }

    private func taskRow(_ task: TodoTask) -> some View {
        HStack(alignment: .top, spacing: 14) {
            Button { vm.toggle(task) } label: {
                Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 26))
                    .foregroundStyle(task.isCompleted ? AppTheme.done : Color.secondary.opacity(0.6))
            }
            .buttonStyle(.plain)

            VStack(alignment: .leading, spacing: 4) {
                Text(task.title)
                    .font(.headline)
                    .strikethrough(task.isCompleted)
                    .foregroundStyle(task.isCompleted ? Color.secondary : Color.primary)
                if !task.description.isEmpty {
                    Text(task.description)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(3)
                }
                Text(task.createdAt, style: .date)
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
                    .padding(.top, 2)
            }
            Spacer(minLength: 0)

            Image(systemName: "chevron.right")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.tertiary)
                .padding(.top, 6)
        }
        .padding(16)
        .card()
        .contentShape(Rectangle())
        .onTapGesture { editingTask = task }
    }

    private var addButton: some View {
        Button { showingAdd = true } label: {
            Image(systemName: "plus")
                .font(.system(size: 24, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: 60, height: 60)
                .background(Circle().fill(AppTheme.accentGradient))
                .shadow(color: AppTheme.accent.opacity(0.4), radius: 12, x: 0, y: 6)
        }
        .accessibilityLabel("Add task")
    }

    private func emptyState(icon: String, title: String, message: String) -> some View {
        VStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(AppTheme.accent.opacity(0.12))
                    .frame(width: 96, height: 96)
                Image(systemName: icon)
                    .font(.system(size: 40))
                    .foregroundStyle(AppTheme.accent)
            }
            Text(title).font(.title3.weight(.semibold))
            Text(message)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.horizontal, 32)
    }
}
